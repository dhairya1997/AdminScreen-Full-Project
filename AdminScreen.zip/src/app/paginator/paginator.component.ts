import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.css']
})
export class PaginatorComponent{

  constructor() { }

  pageNo:number;
  @Input() page: any;
  @Output() pageChange = new EventEmitter();

  previous(){
    let previous: any = { url:this.page.previous };
    this.pageChange.emit(previous);
  }

  next() {
    let next: any = { url: this.page.next };
    this.pageChange.emit(next);
  }

}
