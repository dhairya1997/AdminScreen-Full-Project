import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { MatCardModule,MatCheckboxModule, MatNativeDateModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatTableModule, MatIconModule, MatPaginatorModule, MatTooltipModule } from '@angular/material';
import { AddAccountComponent } from './Account/add-account/add-account.component';
import { AccountListComponent } from './Account/account-list/account-list.component';
import { AddUserComponent } from './User/add-user/add-user.component';
import { UserListComponent } from './User/user-list/user-list.component';

import { ClientListComponent } from './Client/client-list/client-list.component';
import { PaginatorComponent } from './paginator/paginator.component';
import { AddClientComponent } from './Client/add-client/add-client.component';


@NgModule({
  declarations: [
    AppComponent,
    ClientListComponent,
    AddClientComponent,
    AddAccountComponent,
    AddUserComponent,
    PaginatorComponent,
    AccountListComponent,
    UserListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    HttpClientModule,
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule,
    MatCheckboxModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatTableModule, 
    MatIconModule,
    MatPaginatorModule,
    MatTooltipModule,    
    RouterModule.forRoot([
      {path: 'client', component: ClientListComponent},
      {path: 'account', component: AccountListComponent},
      {path: 'user', component: UserListComponent},
      {path: 'addclient', component: AddClientComponent },
      {path: 'addaccount', component: AddAccountComponent},
      {path: 'adduser', component: AddUserComponent},
      {path: '', redirectTo: 'client', pathMatch: 'full'},
      {path: '**', component: ClientListComponent }
    ]) 


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
