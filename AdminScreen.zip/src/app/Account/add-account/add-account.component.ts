import { Component, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { Observable } from 'rxjs';
import { AccountSettings } from '../../Model/account-settings';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {
  originalAccountSettings: AccountSettings={
    
    accountName: null,
    clientName: null,
    status: null,
    startDate: null,
    endDate: null
     };
  startDate: Date;
  endDate: Date;
  accountSettings : AccountSettings = {...this.originalAccountSettings};
  postError = false;
  postErrorMessage = ' ';
constructor(private dataService : AdminService, private router: Router) { 
}
ngOnInit() {
 
  this.startDate = new Date();
  this.endDate= new Date();
}
onBlur(field: NgModel){
console.log('in onBlur: ',field.valid);
}
onHttpError(errorResponse: any){
 console.log('error: ', errorResponse);
  this.postError = true;
}

//method for save button
onSubmit(form : NgForm){
console.log('in onSubmit: ',form.valid);
if(form.valid){this.dataService.postAccountSettingForm(this.accountSettings).subscribe(
result => console.log('success: ',result),
error => this.onHttpError(error)
);

this.router.navigate(['/account']);
}
else{
this.postError = true;
this.postErrorMessage = "Please fix the error";
}}
}
