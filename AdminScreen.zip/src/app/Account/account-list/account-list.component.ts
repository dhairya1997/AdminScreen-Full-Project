import { Component, OnInit } from '@angular/core';
import { AccountSettings } from '../../Model/account-settings';
import { NgModel } from '@angular/forms';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit{

  search:string = "";
  page: any;
  postError = false;
  postErrorMessage = ' ';
  router: any;
  accountData: AccountSettings;
  constructor(private accountListService: AdminService) { }
 // clientAccounts: string =this.accountListService.accountData;
  ngOnInit() {

    let api: any = 'http://127.0.0.1:8000/api/v1/account/';
    this.getData(api);
    // if(this.clientAccounts==''){
    //   this.getData(api);
    // }
    // else{
    //   this.onClientSearch(this.clientAccounts);
    // }
  }
  // onClientSearch(search:any){
  //   this.accountListService.getAccountSearch('http://127.0.0.1:8000/api/v1/account/',search).subscribe(x=>{
  //     console.log(x);
  //     this.page = { count: x.count, next: x.next, previous:x.previous };
  //     this.accountData = x.results;
  //     }, error=>{
  //     console.log(error);});
  // }
  getData(url: any){
    this.accountListService.getAccountInfo(url).subscribe(x=>{
      console.log(x);
      this.page = { count: x.count, next: x.next, previous:x.previous };
      this.accountData = x.results;
      }, error=>{
      console.log(error);});
  }
  onSearch(s:NgModel){
    this.accountListService.getAccountSearch('http://127.0.0.1:8000/api/v1/account/',this.search).subscribe(x=>{
      console.log(x);
      this.page = { count: x.count, next: x.next, previous:x.previous };
      this.accountData = x.results;
      }, error=>{
      console.log(error);});
    
    }
    // getUser(accountName: string){
    //   this.accountListService.userData=accountName;
    // }

  onPageChanged(event: any) {
    this.getData(event.url);
  }
  onHttpError(errorResponse: any){
    console.log('error: ', errorResponse);
     this.postError = true;
     this.postErrorMessage= errorResponse.error.errorMessage;
   }
   accountHead=['Account Name','Client Name','Start Date','End Date','Status'];


}
