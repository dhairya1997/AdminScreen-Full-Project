import { Component, OnInit } from '@angular/core';
import { ClientSettings } from '../../Model/client-setting';
import { NgModel } from '@angular/forms';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit {

  
  search:string = "";
  page: any;
  postError = false;
  postErrorMessage = ' ';
  router: any;
  public clientData: ClientSettings;
  
  constructor(private clientListService: AdminService) {  }
  ngOnInit() {
    
    
    let api: any = 'http://127.0.0.1:8000/api/v1/client/';
    this.getData(api);

  }

  getData(url: any){
    this.clientListService.getClientInfo(url).subscribe(x=>{
      console.log(x);
      this.page = { count: x.count, next: x.next, previous:x.previous };
      this.clientData = x.results;
      }, error=>{
      console.log(error);});
  }
onSearch(s:NgModel){
this.clientListService.getClientSearch('http://127.0.0.1:8000/api/v1/client/',this.search).subscribe(x=>{
  console.log(x);
  this.page = { count: x.count, next: x.next, previous:x.previous };
  this.clientData = x.results;
  }, error=>{
  console.log(error);});

}
// getAccounts(clientName: string){
//   this.clientListService.accountData=clientName;
// }
  onPageChanged(event: any) {
    //this.pageUrl.next(event.url);
    this.getData(event.url);
  }
  onHttpError(errorResponse: any){
    console.log('error: ', errorResponse);
     this.postError = true;
     this.postErrorMessage= errorResponse.error.errorMessage;
   }
   clientHead=['Client Name','Subscription Start','Subscription End','Subscription Key','Client Domain','Status'];
}


