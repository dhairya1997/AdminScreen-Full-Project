import { Component, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { ClientSettings } from '../../Model/client-setting';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {
  originalClientSettings: ClientSettings={
    
    clientName: null,
    createdBy: null,
    subscriptionStart: null,
    subscriptionEnd: null,
    subscriptionKey: null,
    clientDomain: null,
    status: null
  };
  subscriptionStart: Date;
  subscriptionEnd: Date;
  clientSettings : ClientSettings = {...this.originalClientSettings};
  postError = false;
  postErrorMessage = ' ';
  
  

constructor(private clientService : AdminService, private router: Router) { 

}

ngOnInit() {
  
  this.subscriptionStart = new Date();
  this.subscriptionEnd = new Date();

}
onBlur(field: NgModel){
console.log('in onBlur: ',field.valid);
}
onHttpError(errorResponse: any){
 console.log('error: ', errorResponse);
  this.postError = true;
  //this.postErrorMessage= errorResponse.error.errorMessage;

}

//method for save button
onSubmit(form : NgForm){
console.log('in onSubmit: ',form.valid);
if(form.valid){
  this.clientService.postClientSettingForm(this.clientSettings).subscribe(
result => console.log('success: ',result),
error => this.onHttpError(error)
);
this.router.navigate(['/client']);
  }
else{
this.postError = true;
this.postErrorMessage = "Please fix the error";
}
}

  
}