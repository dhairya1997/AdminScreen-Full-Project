//AccountSettings class 
export class AccountSettings{
    
    accountName: string;
    clientName: string;
    status: string;
    startDate: Date;
    endDate: Date;
     
}
