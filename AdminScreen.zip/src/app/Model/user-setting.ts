//UserSettings class 
export class UserSettings{
    
    userName: string;
    password: string;
    lastLoginDate: Date;
    firstName: string;
    lastName: string;
    userEmail: string;
    createdBy: string;
    status: string;
    accountName: string;
 }
