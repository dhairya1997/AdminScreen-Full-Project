//ClientSettings class 
export interface ClientSettings{
    
    clientName: string;
    createdBy: string;
    subscriptionStart: Date;
    subscriptionEnd: Date;
    subscriptionKey: string;
    clientDomain: string;
    status: string;
}