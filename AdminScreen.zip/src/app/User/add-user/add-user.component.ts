import { Component, OnInit } from '@angular/core';
import { UserSettings } from '../../Model/user-setting';
import { NgModel, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  originalUserSettings: UserSettings={
    
    userName: null,
    password: null,
    lastLoginDate: null,
    firstName: null,
    lastName: null,
    userEmail: null,
    accountName: null,
    status:null,
    createdBy: null
  };
    lastLoginDate: Date;
  userSettings : UserSettings = {...this.originalUserSettings};
  postError = false;
  postErrorMessage = ' ';
 
constructor(private userService : AdminService, private router: Router) { 

}

ngOnInit() {
  this.lastLoginDate = new Date();
  
}
onBlur(field: NgModel){
console.log('in onBlur: ',field.valid);
}
onHttpError(errorResponse: any){
 console.log('error: ', errorResponse);
  this.postError = true;
  //this.postErrorMessage= errorResponse.error.errorMessage;

}

// method for save button 
onSubmit(form : NgForm){
console.log('in onSubmit: ',form.valid);
if(form.valid)
{
  this.userService.postUserSettingForm(this.userSettings).subscribe(
  result => console.log('success: ',result),
  error => this.onHttpError(error)
);
this.router.navigate(['/user']);
  }
else{
  this.postError = true;
  this.postErrorMessage = "Please fix the error";
}
}
}

