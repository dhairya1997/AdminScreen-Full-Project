import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, NgModel } from '@angular/forms';
import { UserSettings } from '../../Model/user-setting';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  search:string = "";
  
  page: any;
  postError = false;
  postErrorMessage = ' ';
  router: any;
  userData: UserSettings;
  //userAccounts: string =this.userListService.userData;
  constructor(private userListService: AdminService) { }

  ngOnInit() {

    let api: any = 'http://127.0.0.1:8000/api/v1/user/';
    this.getData(api);
    // if(this.userAccounts==''){
    //   this.getData(api);
    // }
    // else{
    //   this.onAccountsSearch(this.userAccounts);
    // }

  }
  // onAccountsSearch(search:any){
  //   this.userListService.getUserSearch('http://127.0.0.1:8000/api/v1/user/',search).subscribe(x=>{
  //     console.log(x);
  //     this.page = { count: x.count, next: x.next, previous:x.previous };
  //     this.userData = x.results;
  //     }, error=>{
  //     console.log(error);});
  // }

  getData(url: any){
    this.userListService.getUserInfo(url).subscribe(x=>{
      console.log(x);
      this.page = { count: x.count, next: x.next, previous:x.previous };
      this.userData = x.results;
      }, error=>{
      console.log(error);});
  }
  onSearch(s:NgModel){
    this.userListService.getUserSearch('http://127.0.0.1:8000/api/v1/user/',this.search).subscribe(x=>{
      console.log(x);
      this.page = { count: x.count, next: x.next, previous:x.previous };
      this.userData = x.results;
      }, error=>{
      console.log(error);});
    
    }
    

  onPageChanged(event: any) {
    this.getData(event.url);
  }
  onHttpError(errorResponse: any){
    console.log('error: ', errorResponse);
     this.postError = true;
     this.postErrorMessage= errorResponse.error.errorMessage;
   }
   userHead=['User Name','Account Name','First Name','Last Name','Status'];


}

