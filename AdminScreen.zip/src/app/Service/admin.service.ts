import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ClientSettings } from '../Model/client-setting';
import { AccountSettings } from '../Model/account-settings';
import { UserSettings } from '../Model/user-setting';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  
  constructor(private http: HttpClient) { }

   // post method for saving client data
  postClientSettingForm(clientSettings : ClientSettings) : Observable<any>{
    return this.http.post('http://127.0.0.1:8000/api/v1/client/',clientSettings);
  }
   // post method for saving account data
  postAccountSettingForm(accountSettings : AccountSettings) : Observable<any>{
    return this.http.post('http://127.0.0.1:8000/api/v1/account/',accountSettings);
  }
  // post method for saving user data
  postUserSettingForm(userSettings : UserSettings) : Observable<any>{
    return this.http.post('http://127.0.0.1:8000/api/v1/user/',userSettings);
  }
  //method for getting data for client
  getClientInfo(url:any) : Observable<any>{
    return this.http.get(url);
  }
   //method for getting data for client on search
  getClientSearch(url:any, search: string):Observable<any>{
    return this.http.get<any>(`${url}?search=${search}`);
  }
  //method for getting data for account
  getAccountInfo(url:any) : Observable<any>{
    return this.http.get(url);
  }
  //method for getting data for account on search
  getAccountSearch(url:any, search: string):Observable<any>{
    return this.http.get<any>(`${url}?search=${search}`);
  }
  //method for getting data for user
  getUserInfo(url:any) : Observable<any>{
    return this.http.get(url);
  }
  //method for getting data for user on search
  getUserSearch(url:any, search: string):Observable<any>{
    return this.http.get<any>(`${url}?search=${search}`);
  }
   
  // accountData: string='';
  // userData: string='';
  //   get data():string{
  //       return this.accountData,this.userData;
  //   }

  //   set data(value:string){
  //       this.accountData = value;
  //       this.userData = value;
  //       console.log(value);
  //   }




}

   /* 
   postClientSettingForm(id:string,createLeave: CreateLeaveData) : Observable<any>{
   return this.httpclient.post('https://localhost:44395/api/createleave/'+id, createLeave);
   }
    */ 