from django.contrib import admin
from django.urls import path
from clientapp.views import ClientViewset, AccountViewset, UserViewset
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('client', ClientViewset)
router.register('account', AccountViewset)
router.register('user', UserViewset)
# router.register('client/filterdata', ClientViewset)
urlpatterns = router.urls
