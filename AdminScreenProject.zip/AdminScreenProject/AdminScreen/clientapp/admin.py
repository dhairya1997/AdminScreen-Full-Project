from django.contrib import admin
from clientapp.models import Client
# Register your models here.
admin.site.register(Client)

