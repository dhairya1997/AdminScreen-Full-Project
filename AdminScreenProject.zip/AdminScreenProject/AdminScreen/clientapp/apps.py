from django.apps import AppConfig


class ClientappConfig(AppConfig):
    name = 'clientapp'
