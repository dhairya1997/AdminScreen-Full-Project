from django.shortcuts import render
import django_filters.rest_framework
from rest_framework import viewsets
from rest_framework.decorators import action

from clientapp.models import Client, Account, User
from clientapp.serializers import ClientSerializer, AccountSerializer, UserSerializer
from django.core.paginator import Paginator
from rest_framework.response import Response
from rest_framework import filters


# Create your views here.

class ClientViewset(viewsets.ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer

    # @action(detail=False, methods=['Post'], url_path='filterdata')
    # def filter(self, request, *args, **kwargs):
    #     print("demmo")
    #     # queryset = self.get_queryset().filter(status=1)
    #     queryset = Client.objects.filter(clientName=request.data.get('clientName', None))
    #     serializer = ClientSerializer(queryset)
    #     return Response(serializer.data)
    filter_backends = [filters.SearchFilter]
    search_fields = ['clientName', 'subscriptionKey', 'status','clientDomain']
    # filter_backends = [filters.OrderingFilter]
    # ordering_fields = '__all__'
    # ordering = ['clientName']
    # ['clientName']

    # def create(self, request, *args, **kwargs):
    #     serializer=UserSerializer(data=request.data)
    #     if serializer.is_valid():
    #         return Response({'Result':request.data})
    #     else:
    #         print(serializer.errors)
    #         return Response({'Result': serializer.errors})


class AccountViewset(viewsets.ModelViewSet):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['accountName', 'clientName']


class UserViewset(viewsets.ModelViewSet):

    queryset = User.objects.all()
    serializer_class = UserSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['userName', 'status']
    # [django_filters.rest_framework.DjangoFilterBackend]

# class UserViewset(viewsets.ModelViewSet):
#     queryset = User.objects.all()
#     serializer_class = UserSerializer
#     print(serializer_class.data)
# print(serializer_class)
