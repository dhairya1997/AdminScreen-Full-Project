from django.db import models


# Create your models here.

class Client(models.Model):
    clientName = models.CharField(max_length=50)
    createdBy = models.CharField(max_length=25)
    subscriptionStart = models.DateTimeField(null=True)
    subscriptionEnd = models.DateTimeField(null=True)
    subscriptionKey = models.CharField(max_length=10, null=True)
    clientDomain = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=10)
    accounts_count = models.PositiveSmallIntegerField(default=0)


    @property
    def accounts(self):
        return self.account_set.all()


class Account(models.Model):
    accountName = models.CharField(max_length=50)
    client=models.ForeignKey(Client,on_delete=models.CASCADE,null=True)
    clientName = models.CharField(max_length=50,null=True)
    status = models.CharField(max_length=10)
    startDate = models.DateTimeField(null=True)
    endDate = models.DateTimeField(null=True)


class User(models.Model):
    userName = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    accountName = models.ForeignKey(Account,on_delete=models.CASCADE,null=True)
    lastLoginDate = models.DateTimeField(null=True)
    firstName = models.CharField(max_length=25)
    lastName = models.CharField(max_length=25)
    email = models.EmailField(max_length=100)
    # accountName = models.CharField(max_length=50)
    # clientName = models.CharField(max_length=50)
    createdBy = models.CharField(max_length=25)
    status = models.CharField(max_length=10)

# def __str__(self):
#     return self.name
