from rest_framework import serializers
from clientapp.models import Client, Account, User


class ClientSerializer(serializers.ModelSerializer):
    accounts_count = serializers.SerializerMethodField()

    class Meta:
        model = Client
        fields = ('id', 'clientName', 'createdBy', 'subscriptionStart', 'subscriptionEnd', 'subscriptionKey',
                  'clientDomain', 'status', 'accounts_count')

    def get_accounts_count(self, obj):
        return obj.accounts.count()


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = '__all__'


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
            # ('id', 'userName','accountName', 'lastLoginDate', 'firstName', 'lastName', 'createdBy', 'status')
